G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.7*
G04 #@! TF.CreationDate,2026-10-23T21:24:10-05:00*
G04 #@! TF.ProjectId,sensor-carrier,73656e73-6f72-42d6-9361-72726965722e,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.7) date 2026-10-23 21:24:10*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,1.300000*%
%ADD11C,1.800000*%
%ADD12RoundRect,0.250000X-0.550000X-0.550000X0.550000X-0.550000X0.550000X0.550000X-0.550000X0.550000X0*%
%ADD13C,1.600000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,U1*
X-1117400Y2697700D03*
X-1117400Y-2697700D03*
X1117400Y-2697700D03*
X1117400Y2697700D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J1*
X-3810000Y8199999D03*
X-1270000Y8199999D03*
X1270000Y8199999D03*
X3810000Y8199999D03*
G04 #@! TD*
D12*
G04 #@! TO.C,C2*
X2600000Y-7300000D03*
D13*
X5100000Y-7300000D03*
G04 #@! TD*
G04 #@! TO.C,R2*
X7300000Y3810000D03*
X7300000Y-3810000D03*
G04 #@! TD*
G04 #@! TO.C,C1*
X-2500000Y-7800000D03*
X0Y-7800000D03*
G04 #@! TD*
G04 #@! TO.C,R1*
X-7300000Y3810000D03*
X-7300000Y-3810000D03*
G04 #@! TD*
M02*
